from django.db import migrations, models
import django.db.models.deletion
from django.conf import settings

class Migration(migrations.Migration):
    dependencies = [
        ('orders', '0001_initial'),
        ('accounts', '0010_security_hardening'),
    ]
    
    operations = [
        migrations.AddField(
            model_name='order', 
            name='circuit_fingerprint', 
            field=models.CharField(max_length=64, null=True)
        ),
        migrations.AddField(
            model_name='order', 
            name='user_agent', 
            field=models.TextField(null=True)
        ),
        migrations.CreateModel(
            name='OrderAccessLog',
            fields=[
                ('id', models.BigAutoField(primary_key=True, serialize=False)),
                ('order', models.ForeignKey(to='orders.order', on_delete=django.db.models.deletion.CASCADE)),
                ('user', models.ForeignKey(to=settings.AUTH_USER_MODEL, on_delete=django.db.models.deletion.CASCADE)),
                ('action', models.CharField(max_length=50)),
                ('timestamp', models.DateTimeField(auto_now_add=True)),
                ('circuit_fingerprint', models.CharField(max_length=64)),
            ],
        ),
    ]
