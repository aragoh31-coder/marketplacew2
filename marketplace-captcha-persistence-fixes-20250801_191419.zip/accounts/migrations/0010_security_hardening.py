from django.db import migrations, models
import django.core.validators
import re

def validate_crypto_address(address):
    btc_pattern = r'^[13][a-km-zA-HJ-NP-Z1-9]{25,34}$|^bc1[a-z0-9]{39,59}$'
    xmr_pattern = r'^[48][0-9AB][1-9A-HJ-NP-Za-km-z]{93}$'
    return bool(re.match(btc_pattern, address)) or bool(re.match(xmr_pattern, address))

class Migration(migrations.Migration):
    dependencies = [
        ('accounts', '0009_alter_user_totp_secret'),
    ]
    
    operations = [
        migrations.AddField(
            model_name='user', 
            name='locked_until', 
            field=models.DateTimeField(null=True, blank=True)
        ),
    ]
