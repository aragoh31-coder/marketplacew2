module.exports = {
  mode: 'jit',
  content: ['./templates/**/*.html', './**/*.py'],
  theme: { 
    extend: {
      colors: {
        'purple-start': '#4e54c8',
        'purple-end': '#8f94fb',
        'accent': '#ff79c6',
      }
    } 
  },
  plugins: [require('@tailwindcss/forms'), require('@tailwindcss/typography')],
};
